package com.knoldus.actor

import akka.actor.Actor
import akka.event.Logging
import com.knoldus.app.Tweet

import scala.collection.mutable.ListBuffer

class TweetWorker extends Actor{

  var counter=0
  val logger = Logging(context.system,this)

  def receive={
    case tweet:  List[Tweet] =>
      counter += 1
      logger.info(s"${tweet}")

    case _=>println("worker...worked!")

  }

}
