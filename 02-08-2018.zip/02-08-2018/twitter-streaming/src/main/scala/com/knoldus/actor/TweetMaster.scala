package com.knoldus.actor

import akka.actor.{Actor, Props, Terminated}
import akka.routing.{ActorRefRoutee, FromConfig, RoundRobinRoutingLogic, Router}
import com.knoldus.app.Tweet

import scala.collection.mutable.ListBuffer

class TweetMaster extends Actor {
  var router =  context.actorOf(FromConfig.props(Props[TweetWorker].withDispatcher("my-dispatcher")), "TweetMaster")
  def receive = {
    case buffer: List[Tweet] =>
      for{
        i<-buffer.indices
        tweets=buffer(i)
        } yield router ! tweets
    case _ => println("@@@@@@@@@@@")

  }

}
